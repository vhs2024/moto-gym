# MOTO GYM — Dark Manga App

Personal fitness dashboard with a dark manga/anime aesthetic.

## GitHub Pages

This project is a static site. Enable GitHub Pages from the repository's **Settings → Pages** and select **GitHub Actions**.

The included workflow deploys `index.html` automatically.
